from flask import Flask, render_template, request
from pymongo import MongoClient

app = Flask(__name__)

# MongoDB connection
client = MongoClient("mongodb://localhost:27017/")
db = client['CollegeFeedback']             # Match name exactly
collection = db['feedbacks']               # Use 'collection', not 'feedbacks' directly

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/feedback')
def feedback():
    return render_template('feedback.html')

@app.route('/submit', methods=['POST'])
def submit():
    name = request.form['name']
    department = request.form['department']
    faculty = request.form['faculty']
    feedback_text = request.form['feedback']
    rating = request.form['rating']

    try:
        collection.insert_one({
            'name': name,
            'department': department,
            'faculty': faculty,
            'feedback': feedback_text,
            'rating': rating
        })
        print("✅ Data inserted successfully!")
    except Exception as e:
        print("❌ Error inserting data:", e)

    return render_template('thankyou.html', name=name)

if __name__ == '__main__':
    app.run(debug=True)
